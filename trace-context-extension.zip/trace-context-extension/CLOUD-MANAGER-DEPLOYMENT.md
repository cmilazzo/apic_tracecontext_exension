# Cloud Manager Deployment Guide

## Quick Deployment (5 Minutes)

This guide walks through deploying the W3C Trace Context extension via IBM API Connect Cloud Manager.

---

## Prerequisites

✓ IBM API Connect v10.0.1.0 or later  
✓ Cloud Manager access with Administrator role  
✓ Gateway Service already configured  
✓ Extension zip file: `trace-context-extension.zip`

---

## Step 1: Upload Extension to Cloud Manager

### Via Web UI

1. **Login to Cloud Manager**
   - Navigate to: `https://<cloud-manager-host>/admin`
   - Login with admin credentials

2. **Navigate to Extensions**
   - Click **Resources** (left sidebar)
   - Click **Gateway Extensions**

3. **Add Extension**
   - Click **Add** button
   - Click **Gateway Extension**
   - Click **Choose File** and select `trace-context-extension.zip`
   - The system will extract and validate the extension
   - Review the extension details:
     - Name: `trace-context`
     - Version: `1.0.0`
     - Title: `W3C Trace Context Extension`
   - Click **Save**

4. **Verify Upload**
   - Extension should appear in the list
   - Status should be **Available**

### Via CLI

```bash
# Login to API Manager
apic login --server <manager-host> --realm admin/default-idp-1

# Set context to organization
apic orgs:list --server <manager-host>
apic config:set org=<org-name>

# Upload extension
apic extensions:create trace-context-extension.zip \
  --scope org \
  --server <manager-host>

# Verify upload
apic extensions:list --scope org --server <manager-host>
```

---

## Step 2: Enable Extension on Gateway Service

### Via Web UI

1. **Navigate to Gateway Services**
   - Click **Resources** → **Availability Zones**
   - Click on your availability zone
   - Click **Gateway Services** tab

2. **Select Gateway Service**
   - Click on the gateway service you want to configure
   - Example: `datapower-api-gateway`

3. **Enable Extension**
   - Click **Extensions** tab
   - Click **Edit** button
   - Find **W3C Trace Context Extension** in the list
   - Toggle the switch to **ON** (enabled)
   - Click **Save**

4. **Sync Gateway**
   - The gateway will automatically sync the configuration
   - Wait for sync to complete (usually 10-30 seconds)
   - Status should show **Active**

### Via CLI

```bash
# List gateway services
apic gateway-services:list \
  --availability-zone <zone-name> \
  --server <manager-host>

# Enable extension on gateway service
apic gateway-extensions:set \
  --gateway-service <gateway-service-name> \
  --availability-zone <zone-name> \
  --extension trace-context \
  --enabled true \
  --server <manager-host>

# Verify
apic gateway-extensions:get \
  --gateway-service <gateway-service-name> \
  --availability-zone <zone-name> \
  --server <manager-host>
```

---

## Step 3: Verify Deployment

### Test API Call

```bash
# Make a test API call to any API on your gateway
curl -v https://<gateway-host>:9443/api/v1/test

# Expected response headers:
# HTTP/1.1 200 OK
# X-Trace-Id: 550e8400e29b41d4a716446655440000
# X-Correlation-ID: 550e8400-e29b-41d4-a716-446655440000
```

### Check Gateway Logs

1. **Via Cloud Manager**
   - Navigate to: **Dashboard** → **Gateway Services**
   - Select your gateway service
   - Click **Logs** tab
   - Filter for: `Trace Context`
   
   Expected log entries:
   ```
   [Trace Context] Processing request with APIC correlation ID: ...
   [Trace Context] Trace context configured successfully
   [Trace Context Response] Request completed - TraceID: ...
   ```

2. **Via CLI**
   ```bash
   # Get recent logs
   apic gateway-services:logs \
     --gateway-service <gateway-service-name> \
     --availability-zone <zone-name> \
     --server <manager-host> \
     --tail 100
   ```

### Verify Backend Headers

Check your backend service logs to confirm it receives:
- `traceparent: 00-{32 hex}-{16 hex}-01`
- `tracestate: apic={UUID}`
- `X-Correlation-ID: {UUID}`
- `X-Global-Transaction-ID: {UUID}`

---

## Step 4: Roll Out to Additional Gateways (Optional)

If you have multiple gateway services:

### Via Web UI

Repeat Step 2 for each gateway service:
1. **Resources** → **Availability Zones** → Select zone
2. **Gateway Services** → Select service
3. **Extensions** → **Edit**
4. Enable **W3C Trace Context Extension**
5. **Save**

### Via CLI

```bash
# List all gateway services
apic gateway-services:list-all --server <manager-host>

# Enable on each gateway service
for gateway in gateway1 gateway2 gateway3; do
  apic gateway-extensions:set \
    --gateway-service $gateway \
    --availability-zone <zone-name> \
    --extension trace-context \
    --enabled true \
    --server <manager-host>
done
```

---

## Configuration

### Enable Verbose Logging (Development/Testing)

1. Download the extension package
2. Edit `trace-context-request.js`:
   ```javascript
   var CONFIG = {
       VERBOSE_LOGGING: true,  // Change to true
       // ... rest of config
   };
   ```
3. Re-zip the extension
4. Upload new version via Cloud Manager
5. Existing enabled gateways will auto-update

### Disable Response Headers

1. Edit `trace-context-response.js`:
   ```javascript
   var CONFIG = {
       ENABLED: false,  // Change to false
       // ... rest of config
   };
   ```
2. Re-zip and re-upload

---

## Management Operations

### Check Extension Status

**Via Web UI:**
- **Resources** → **Gateway Extensions**
- View status, version, and which gateways have it enabled

**Via CLI:**
```bash
apic extensions:get trace-context \
  --scope org \
  --server <manager-host>
```

### Update Extension

1. Modify the GatewayScript files as needed
2. Increment version in `extension.json`
3. Re-zip the package
4. Upload via Cloud Manager (**Add** → **Gateway Extension**)
5. Gateway services will auto-update

### Disable Extension

**Via Web UI:**
1. **Resources** → **Availability Zones** → **Gateway Services**
2. Select gateway service
3. **Extensions** tab → **Edit**
4. Toggle extension **OFF**
5. **Save**

**Via CLI:**
```bash
apic gateway-extensions:set \
  --gateway-service <gateway-service-name> \
  --availability-zone <zone-name> \
  --extension trace-context \
  --enabled false \
  --server <manager-host>
```

### Remove Extension Completely

1. **Disable on all gateway services** (see above)
2. **Delete extension:**
   - Via UI: **Resources** → **Gateway Extensions** → Select → **Delete**
   - Via CLI:
     ```bash
     apic extensions:delete trace-context \
       --scope org \
       --server <manager-host>
     ```

---

## Troubleshooting

### Extension Upload Fails

**Symptoms:**
- Upload fails with validation error
- Extension doesn't appear in list

**Solutions:**
1. Verify zip file structure:
   ```
   trace-context-extension.zip
   ├── extension.json
   ├── trace-context-request.js
   ├── trace-context-response.js
   └── README.md
   ```
2. Check `extension.json` is valid JSON
3. Ensure file names match references in `extension.json`
4. Check Cloud Manager logs for detailed error

### Extension Not Activating

**Symptoms:**
- Extension enabled but headers not generated
- No log entries

**Solutions:**
1. Check gateway sync status: Should show **Active**
2. Wait 30 seconds after enabling for sync
3. Restart gateway service if needed
4. Check Cloud Manager → Gateway Service → Status

### Headers Not Appearing

**Symptoms:**
- API calls succeed but no trace headers in response
- Backend doesn't receive trace headers

**Solutions:**
1. Verify extension is enabled on correct gateway service
2. Check gateway logs for errors
3. Confirm APIC correlation ID is present
4. Test with verbose logging enabled

### Performance Degradation

**Symptoms:**
- Increased API latency after enabling extension
- Gateway CPU/memory usage increased

**Solutions:**
1. Disable verbose logging (`VERBOSE_LOGGING: false`)
2. Check gateway resource allocation
3. Review DataPower metrics in Cloud Manager
4. Consider disabling response handler if not needed

---

## Rollback Procedure

### Quick Disable (Reversible)

```bash
# Via CLI
apic gateway-extensions:set \
  --gateway-service <gateway-service-name> \
  --availability-zone <zone-name> \
  --extension trace-context \
  --enabled false \
  --server <manager-host>

# Or via UI: Toggle extension OFF
```

APIs will immediately stop receiving trace context headers.

### Complete Removal

1. Disable extension on all gateway services
2. Delete extension from Cloud Manager
3. Verify headers no longer generated

---

## Multi-Environment Deployment

### Development → Test → Production

**Development:**
```bash
# Upload to dev environment
apic login --server dev-manager --realm admin/default-idp-1
apic extensions:create trace-context-extension.zip --scope org

# Enable on dev gateway
apic gateway-extensions:set \
  --gateway-service dev-gateway \
  --extension trace-context \
  --enabled true
```

**Test:**
```bash
# Export from dev
apic extensions:get trace-context --scope org --output trace-context.zip

# Import to test
apic login --server test-manager --realm admin/default-idp-1
apic extensions:create trace-context.zip --scope org
apic gateway-extensions:set \
  --gateway-service test-gateway \
  --extension trace-context \
  --enabled true
```

**Production:**
```bash
# Same process as test
apic login --server prod-manager --realm admin/default-idp-1
apic extensions:create trace-context.zip --scope org
apic gateway-extensions:set \
  --gateway-service prod-gateway \
  --extension trace-context \
  --enabled true
```

---

## Validation Checklist

- [ ] Extension uploaded to Cloud Manager
- [ ] Extension status shows **Available**
- [ ] Extension enabled on gateway service(s)
- [ ] Gateway service status shows **Active**
- [ ] Test API call returns trace headers
- [ ] Gateway logs show trace context messages
- [ ] Backend receives trace headers
- [ ] Observability tools receive W3C trace context
- [ ] No performance degradation observed

---

## Next Steps

After successful deployment:

1. **Configure Observability Tools**
   - Update APM configuration to consume W3C Trace Context
   - Create dashboards for distributed tracing
   - Set up alerts based on trace data

2. **Team Training**
   - Share trace ID format with development teams
   - Document query patterns for support teams
   - Update runbooks with trace-based troubleshooting

3. **Monitor Performance**
   - Track gateway metrics for 24-48 hours
   - Verify no latency increase
   - Confirm trace coverage across APIs

---

## Support

**For Issues:**
1. Check gateway logs in Cloud Manager
2. Verify extension configuration
3. Review this guide's troubleshooting section
4. Check IBM API Connect documentation

**Log Locations:**
- Cloud Manager: **Dashboard** → **Gateway Services** → **Logs**
- CLI: `apic gateway-services:logs`
- DataPower: Access via gateway shell if needed

---

## Summary

You have successfully deployed the W3C Trace Context extension! Your API gateway now:

✅ Automatically generates W3C Trace Context headers  
✅ Maps APIC correlation IDs to trace IDs  
✅ Maintains backward compatibility  
✅ Enables distributed tracing without API changes

All APIs now participate in standards-based distributed tracing.
